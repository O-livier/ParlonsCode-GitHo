package parlons.code.githo.app.utilities;

public class Api {
	
	private static final String GIT_HUB_API_USER_BASE_URL = "https://api.github.com/users/";
	
	public static String getGitHubUserUrl(UserName userName) {
		return GIT_HUB_API_USER_BASE_URL+userName.getUserName();
	};
}
