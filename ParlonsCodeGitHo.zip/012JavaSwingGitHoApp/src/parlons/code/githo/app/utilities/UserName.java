package parlons.code.githo.app.utilities;

public enum UserName {
	OLIVIER("O-livier"),
	HONORE("mercuryseries");
	
	private String userName;
	private UserName(String username) {
		this.userName = username;
	}
	public String getUserName() {
		return this.userName;
	}
}
