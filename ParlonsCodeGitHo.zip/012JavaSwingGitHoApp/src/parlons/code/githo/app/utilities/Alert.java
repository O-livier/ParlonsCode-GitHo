package parlons.code.githo.app.utilities;

import java.awt.Component;
import javax.swing.JOptionPane;

public class Alert {

	public static String GENERIC_ERROR_MESSAGE = "Veuillez réessayer s.v.p.";
	public static String GENERIC_CONNEXION_ERROR_MESSAGE = "Vérifiez votre connexion à internet.";

	public static void errorMessage(Component component, String message) {
		JOptionPane.showMessageDialog(component, message, "Error", JOptionPane.ERROR_MESSAGE);

	}

	public static void errorMessage(Component component) {
		errorMessage(component, GENERIC_ERROR_MESSAGE);
	}
}
