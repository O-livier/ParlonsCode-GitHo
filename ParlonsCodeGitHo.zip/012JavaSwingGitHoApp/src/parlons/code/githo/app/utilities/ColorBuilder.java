package parlons.code.githo.app.utilities;

import java.awt.Color;

// Petite classe qui se base sur le "Builder Pattern"
// Elle construit une couleur associée à un transparence
public class ColorBuilder {

	public final static int TRANSPARENT = 128;

	private Color color;
	private int transparency = 255;

	public ColorBuilder setColor(Color color) {
		this.color = color;
		return this;
	}

	public ColorBuilder setTransparency(int transparency) {
		this.transparency = transparency;
		return this;
	}

	public Color buildColor() {
		return new Color(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), this.transparency);
	}

}
