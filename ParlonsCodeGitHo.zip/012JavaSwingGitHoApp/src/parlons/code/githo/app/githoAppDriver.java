package parlons.code.githo.app;

public class githoAppDriver {

	public static void main(String[] args) {
		//GitHoFrame githoFrame = new GitHoFrame();
		GitHoFrame2 gitHoFrame2 = new GitHoFrame2();
		//githoFrame.start();

	}

}
