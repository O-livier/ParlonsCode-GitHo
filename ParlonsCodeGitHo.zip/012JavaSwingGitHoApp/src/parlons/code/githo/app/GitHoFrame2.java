package parlons.code.githo.app;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
//import parlons.code.githo.app.GitHoFrame.GitHubEnQueue;
import parlons.code.githo.app.models.GitHubUser;
import parlons.code.githo.app.models.UserDataBuilder;
import parlons.code.githo.app.utilities.Alert;
import parlons.code.githo.app.utilities.Api;
import parlons.code.githo.app.utilities.ColorBuilder;
import parlons.code.githo.app.utilities.InterventionImage;
import parlons.code.githo.app.utilities.UserName;

public class GitHoFrame2 extends JFrame {

	private static final long serialVersionUID = 4978957941753828233L;
	private static final Font DEFAULT_FONT = new Font("San Fransico", Font.PLAIN, 25);
	private static final Color WHITE = new ColorBuilder().setColor(Color.WHITE).buildColor();
	private static final Color WHITE_TRANSPARENT = new ColorBuilder().setColor(Color.WHITE)
			.setTransparency(ColorBuilder.TRANSPARENT).buildColor();
	private static final Color BACK_GROUND_COLOR = new ColorBuilder().setColor(Color.decode("#3D4852")).buildColor();

	private JPanel contentPanel;
	private JPanel userDataPanel;
	private GitHubUser gitHubUser;
	private JLabel userNameLabel;
	private JLabel userProfessionLabel;
	private JLabel userAvatarLabel;
	private JLabel subscribersAmountLabel;
	private JLabel subscriptionsAmountLabel;
	private JLabel userLocationLabel;

	public GitHoFrame2() {
		init();
		httpRequest();

	}

	public void frameCharacteristics() {
		if(!isVisible()) {
			contentPanel = new JPanel();
			contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
			contentPanel.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
			contentPanel.setBackground(BACK_GROUND_COLOR);

			userNameLabel = new JLabel(gitHubUser.getUserNameData().toUpperCase(), JLabel.CENTER);
			userNameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
			userNameLabel.setFont(DEFAULT_FONT);
			userNameLabel.setForeground(WHITE);
			userNameLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

			userProfessionLabel = new JLabel(gitHubUser.getUserBioData(), JLabel.CENTER);
			userProfessionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
			userProfessionLabel.setFont(DEFAULT_FONT.deriveFont(20f));
			userProfessionLabel.setForeground(WHITE_TRANSPARENT);
			userProfessionLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

			userAvatarLabel = new JLabel("");
			userAvatarLabel.setHorizontalAlignment(JLabel.CENTER);
			userAvatarLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
			userAvatarLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

			avatarCtrl();

			userDataPanel = new JPanel(new GridLayout(2, 2));
			userDataPanel.setAlignmentX(JPanel.CENTER_ALIGNMENT);
			userDataPanel.setBackground(BACK_GROUND_COLOR);

			JLabel subscribersLabel = new JLabel("Abonnés", JLabel.CENTER);
			subscribersLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
			subscribersLabel.setForeground(WHITE_TRANSPARENT);
			subscribersLabel.setFont(DEFAULT_FONT.deriveFont(20f));

			subscribersAmountLabel = new JLabel(gitHubUser.getUserFollowersData(), JLabel.CENTER);
			subscribersAmountLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
			subscribersAmountLabel.setForeground(WHITE);
			subscribersAmountLabel.setFont(DEFAULT_FONT);

			JLabel subscriptionsLabel = new JLabel("Abonnements", JLabel.CENTER);
			subscriptionsLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
			subscriptionsLabel.setForeground(WHITE_TRANSPARENT);
			subscriptionsLabel.setFont(DEFAULT_FONT.deriveFont(20));

			subscriptionsAmountLabel = new JLabel(gitHubUser.getUserDataFollowing(), JLabel.CENTER);
			subscriptionsAmountLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
			subscriptionsAmountLabel.setForeground(WHITE);
			subscriptionsAmountLabel.setFont(DEFAULT_FONT);

			userDataPanel.add(subscribersLabel);
			userDataPanel.add(subscriptionsLabel);
			userDataPanel.add(subscribersAmountLabel);
			userDataPanel.add(subscriptionsAmountLabel);

			userLocationLabel = new JLabel(gitHubUser.getUserLocationData(), JLabel.CENTER);
			userLocationLabel.setAlignmentX(JLabel.CENTER_ALIGNMENT);
			userLocationLabel.setForeground(WHITE);
			userLocationLabel.setFont(DEFAULT_FONT.deriveFont(20f));
			userLocationLabel.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));

			contentPanel.add(userNameLabel);
			contentPanel.add(userProfessionLabel);
			contentPanel.add(userAvatarLabel);
			contentPanel.add(userDataPanel);
			contentPanel.add(userLocationLabel);

			setContentPane(contentPanel);
			setTitle("GitHo");
			setAlwaysOnTop(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setLocationByPlatform(true);

			pack();
			setVisible(true);
		}else {
			upDate();
		}
		
	}

	private void avatarCtrl() {
		try {
			URL url = new URL(gitHubUser.getUserDataAvatarURL());
			BufferedImage bufferedImage = ImageIO.read(url);
			bufferedImage = InterventionImage.makeRoundedCorner(bufferedImage, 600);
			ImageIcon icon = InterventionImage.scale(bufferedImage, 200, 200);
			userAvatarLabel.setText("");
			userAvatarLabel.setIcon(icon);
		} catch (IOException e) {
			// Alert.errorMessage(contentPanel, "Impossible d'afficher l'avatar.");
			userAvatarLabel.setText(gitHubUser.getUserDataAvatarURL());
			userAvatarLabel.setFont(DEFAULT_FONT.deriveFont(80f));
			userAvatarLabel.setForeground(WHITE);

		}
	}

	private void upDate() {
		userNameLabel.setText(gitHubUser.getUserNameData().toUpperCase());
		userProfessionLabel.setText(gitHubUser.getUserBioData());
		avatarCtrl();
		subscribersAmountLabel.setText(gitHubUser.getUserFollowersData());
		subscriptionsAmountLabel.setText(gitHubUser.getUserDataFollowing());
		userLocationLabel.setText(gitHubUser.getUserLocationData());
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(500, 600);
	}

	@Override
	public Dimension getMinimumSize() {
		return new Dimension(500, 600);
	}

	@Override
	public Dimension getMaximumSize() {
		return new Dimension(500, 600);
	}

	private void init() {
		gitHubUser = new UserDataBuilder().setUserBioData("...")
										  .setUserDataAvatarURL("--")
										  .setUserDataFollowing("--")
										  .setUserFollowersData("--")
										  .setUserLocationData("Récupération des informations de profil...")
										  .setUserNameData("--")
										  .build();
		SwingUtilities.invokeLater(() -> {
			frameCharacteristics();
		});

	}

	private void httpRequest() {
		GitHubEnQueue gitHubEnQueue = new GitHubEnQueue(UserName.HONORE);
		gitHubEnQueue.run();
	}

	private class GitHubEnQueue {
		private UserName userName;
		private String jsonData;

		private GitHubEnQueue(UserName userName) {
			this.userName = userName;

		}

		private void run() {
			OkHttpClient client = new OkHttpClient();
			String apiURL = Api.getGitHubUserUrl(userName);
			Request request = new Request.Builder().url(apiURL).build();
			Call call = client.newCall(request);
			call.enqueue(new Callback() {

				@Override
				public void onResponse(Call call, Response response) {
					try (ResponseBody body = response.body()) {
						if (response.isSuccessful()) {
							jsonData = response.body().string();
							getGithubUserDetails(jsonData);
							start();
						} else {
							Alert.errorMessage(contentPanel, Alert.GENERIC_ERROR_MESSAGE);
						}
					} catch (ParseException | IOException e) {
						Alert.errorMessage(contentPanel, Alert.GENERIC_ERROR_MESSAGE);
					}
				}

				@Override
				public void onFailure(Call call, IOException e) {
					Alert.errorMessage(contentPanel, Alert.GENERIC_CONNEXION_ERROR_MESSAGE);
				}
			});
		}

	}

	public void start() {
		SwingUtilities.invokeLater(() -> {
				frameCharacteristics();
		});
	}

	private void getGithubUserDetails(String jsonData) throws ParseException {
		JSONObject userData;
		userData = (JSONObject) JSONValue.parseWithException(jsonData);
		UserDataBuilder userDataBuilder = new UserDataBuilder();
		gitHubUser = userDataBuilder.setUserNameData((String) userData.get("name"))
				.setUserBioData((String) userData.get("bio")).setUserDataAvatarURL((String) userData.get("avatar_url"))
				.setUserDataFollowing((String) String.valueOf(userData.get("following")))
				.setUserFollowersData((String) String.valueOf(userData.get("followers")))
				.setUserLocationData((String) userData.get("location"))
				.build();
	}
}
