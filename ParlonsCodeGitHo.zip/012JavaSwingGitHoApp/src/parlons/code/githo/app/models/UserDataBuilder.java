package parlons.code.githo.app.models;

public class UserDataBuilder {
	
	private String userNameData;
	private String userBioData;
	private String userFollowersData;
	private String userDataFollowing;
	private String userLocationData;
	private String userDataAvatarURL;	
	
	
	public UserDataBuilder setUserNameData(String userNameData) {
		this.userNameData = userNameData;
		return this;
	}		
	
	public UserDataBuilder setUserBioData(String userBioData) {
		this.userBioData = userBioData;
		return this;
	}	
	
	public UserDataBuilder setUserFollowersData(String userFollowersData) {
		this.userFollowersData = userFollowersData;
		return this;
	}
	
	public UserDataBuilder setUserDataFollowing(String userDataFollowing) {
		this.userDataFollowing = userDataFollowing;
		return this;
	}
	
	public UserDataBuilder setUserLocationData(String userLocationData) {
		this.userLocationData = userLocationData;
		return this;
	}
	
	public UserDataBuilder setUserDataAvatarURL(String userDataAvatarURL) {
		this.userDataAvatarURL = userDataAvatarURL;
		return this;
	}
	
	public GitHubUser build() {
		return new GitHubUser(userNameData, userBioData, userFollowersData, userDataFollowing, userLocationData, userDataAvatarURL);
	}

}
