package parlons.code.githo.app.models;

public class GitHubUser {
	private String userNameData;
	private String userBioData;
	private String userFollowersData;
	private String userFollowingData;
	private String userLocationData;
	private String userDataAvatarURL;
	
	public GitHubUser(String userNameData, String userBioData, String userFollowersData, String userDataFollowing,
			String userLocationData, String userDataAvatarURL) {
		
		this.userNameData = userNameData;
		this.userBioData = userBioData;
		this.userFollowersData = userFollowersData;
		this.userFollowingData = userDataFollowing;
		this.userLocationData = userLocationData;
		this.userDataAvatarURL = userDataAvatarURL;
	}

	public String getUserNameData() {
		return userNameData;
	}

	public String getUserBioData() {
		return userBioData;
	}

	public String getUserFollowersData() {
		return userFollowersData;
	}

	public String getUserDataFollowing() {
		return userFollowingData;
	}

	public String getUserLocationData() {
		return userLocationData;
	}

	public String getUserDataAvatarURL() {
		return userDataAvatarURL;
	}
	
	@Override
	public String toString() {
		return "Données utilisateur à afficher :"
				+ " Nom = " + userNameData
				+ " Métier = " + userBioData
				+ " Abonnés = " + userFollowersData
				+ " Abonnements = " + userFollowersData 
				+ " Position = " + userLocationData
				+ " Avatar = " + userDataAvatarURL;
				
	}
	
	
}
