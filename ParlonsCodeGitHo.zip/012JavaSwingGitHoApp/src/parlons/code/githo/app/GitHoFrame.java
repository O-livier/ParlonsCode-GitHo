package parlons.code.githo.app;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.io.IOException;
import java.util.concurrent.ExecutionException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import parlons.code.githo.app.models.GitHubUser;
import parlons.code.githo.app.models.UserDataBuilder;
import parlons.code.githo.app.utilities.Alert;
import parlons.code.githo.app.utilities.Api;
import parlons.code.githo.app.utilities.UserName;

public class GitHoFrame extends JFrame {

	private static final long serialVersionUID = 7246631344452247032L;
	private JPanel contentPanel;
	private GitHubUser gitHubUser;
	
	public GitHoFrame() {
		init();//Initialisation de gitHubUser
		httpRequest();// Accès au site GitHub
		start();//Lance l'application graphique.
	}

	@Override
	public Dimension getPreferredSize() {
		return new Dimension(400, 600);
	}

	@Override
	public Dimension getMinimumSize() {
		return new Dimension(400, 600);
	}

	@Override
	public Dimension getMaximumSize() {
		return new Dimension(400, 600);
	}

	private void init() {
		gitHubUser = new UserDataBuilder().setUserBioData("Profession")
										  .setUserDataAvatarURL("")
										  .setUserDataFollowing("Subscribers")
										  .setUserFollowersData("Subscriptions")
										  .setUserLocationData("Country")
										  .setUserNameData("Name")
										  .build();
											
		
	}

	
	public void start() {
		SwingUtilities.invokeLater(() -> {
			frameCharacteristics();
		});

	}

	private void frameCharacteristics() {
		GridBagLayout bagLayout = new GridBagLayout();
		GridBagConstraints bagConstraints = new GridBagConstraints();
		GridBagConstraints bagConstraints2 = new GridBagConstraints();

		Font bigTextFont = new Font("SansSerif", Font.PLAIN, 25);
		Font smallTextFont = new Font("SansSerif", Font.PLAIN, 20);
		ImageIcon bobIcon = new ImageIcon(getClass().getResource("/ressources/bob.png"));
		JLabel bobLabel = new JLabel();
		bobLabel.setIcon(bobIcon);
		bobLabel.setHorizontalAlignment(JLabel.CENTER);


		JLabel nameLabel = new JLabel(gitHubUser.getUserNameData().toUpperCase(),JLabel.CENTER);//("Name".toUpperCase(), JLabel.CENTER);
		nameLabel.setFont(bigTextFont);
		nameLabel.setForeground(new AppColor().setColor(Color.WHITE).buildColor());

		JLabel professionLabel = new JLabel("Profession", JLabel.CENTER);
		professionLabel.setFont(smallTextFont);
		professionLabel
				.setForeground(new AppColor().setColor(Color.WHITE).setTransparency(AppColor.TRANSPARENT).buildColor());

		JLabel subscribersLabel = new JLabel("Subscribers", JLabel.CENTER);
		subscribersLabel.setFont(bigTextFont);
		subscribersLabel.setForeground(new AppColor().setColor(Color.WHITE).buildColor());

		JLabel subscribersAmountLabel = new JLabel("SubscribersAmount", JLabel.CENTER);
		subscribersAmountLabel.setFont(smallTextFont);
		subscribersAmountLabel
				.setForeground(new AppColor().setColor(Color.WHITE).setTransparency(AppColor.TRANSPARENT).buildColor());

		JLabel subscriptionsLabel = new JLabel("Subsciptions", JLabel.CENTER);
		subscriptionsLabel.setFont(bigTextFont);
		subscriptionsLabel.setForeground(new AppColor().setColor(Color.WHITE).buildColor());

		JLabel subscriptionsAmountLabel = new JLabel("SubsciptionsAmount", JLabel.CENTER);
		subscriptionsAmountLabel.setFont(smallTextFont);
		subscriptionsAmountLabel
				.setForeground(new AppColor().setColor(Color.WHITE).setTransparency(AppColor.TRANSPARENT).buildColor());

		JLabel countryLabel = new JLabel("Country", JLabel.CENTER);
		countryLabel.setFont(bigTextFont);
		countryLabel.setForeground(new AppColor().setColor(Color.WHITE).buildColor());

		contentPanel = new JPanel(new BorderLayout());
		contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		contentPanel.setLayout(bagLayout);
		contentPanel.setBackground(new AppColor().setColor(Color.decode("#3D4852")).buildColor());
		bagConstraints.fill = GridBagConstraints.HORIZONTAL;
		bagConstraints2.fill = GridBagConstraints.HORIZONTAL;
		// bagConstraints.anchor = GridBagConstraints.NORTH;
		bagConstraints.gridx = 0;
		bagConstraints.gridy = 0;
		bagConstraints.weightx = 1.0;
		bagConstraints.weighty = 1.0;

		bagConstraints.gridwidth = GridBagConstraints.REMAINDER;
		contentPanel.add(customisedComponent(nameLabel, bagLayout, bagConstraints));

		bagConstraints.gridx = 0;
		bagConstraints.gridy = 1;
		contentPanel.add(customisedComponent(professionLabel, bagLayout, bagConstraints));

		bagConstraints.gridx = 0;
		bagConstraints.gridy = 2;
		contentPanel.add(customisedComponent(bobLabel, bagLayout, bagConstraints));

		bagConstraints.gridx = 0;
		bagConstraints.gridy = 3;
		bagConstraints.gridwidth = GridBagConstraints.RELATIVE;
		contentPanel.add(customisedComponent(subscribersLabel, bagLayout, bagConstraints));

		bagConstraints.gridx = 1;
		bagConstraints.gridy = 3;
		contentPanel.add(customisedComponent(subscriptionsLabel, bagLayout, bagConstraints));

		bagConstraints.gridx = 0;
		bagConstraints.gridy = 4;
		bagConstraints.gridwidth = GridBagConstraints.RELATIVE;
		contentPanel.add(customisedComponent(subscribersAmountLabel, bagLayout, bagConstraints));

		bagConstraints.gridx = 1;
		bagConstraints.gridy = 4;
		contentPanel.add(customisedComponent(subscriptionsAmountLabel, bagLayout, bagConstraints));

		bagConstraints.gridwidth = GridBagConstraints.REMAINDER;
		bagConstraints.gridx = 0;
		bagConstraints.gridy = 5;
		contentPanel.add(customisedComponent(countryLabel, bagLayout, bagConstraints));

		setContentPane(contentPanel);

		setTitle("Githo");
		setAlwaysOnTop(true);
		// setLocationByPlatform(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		pack();
		setVisible(true);
		
	}

	private JComponent customisedComponent(JComponent component, GridBagLayout bagLayout,
			GridBagConstraints bagConstraints) {
		bagLayout.setConstraints(component, bagConstraints);
		return component;

	}

	private void httpRequest() {
		GitHubEnQueue gitHubEnQueue = new GitHubEnQueue(UserName.OLIVIER);
		gitHubEnQueue.run();
	}

	private void httpRequest1() {
		long strart = System.currentTimeMillis();
		// new GitHubSynchrone(UserName.OLIVIER);
		// new GitHubWorker(UserName.OLIVIER).execute();
		// new GitHubWorker(UserName.HONORE).execute();
		new GitHubEnQueue(UserName.OLIVIER).run();
		long stop = System.currentTimeMillis();
		System.out.println(String.valueOf(stop - strart));
	}

	// Petite classe qui se base sur le "Builder Pattern"
	// Elle construit une couleur associée à un transparence
	private class AppColor {
		private final static int TRANSPARENT = 128;

		private Color color;
		private int transparency = 255;

		public AppColor setColor(Color color) {
			this.color = color;
			return this;
		}

		public AppColor setTransparency(int transparency) {
			this.transparency = transparency;
			return this;
		}

		public Color buildColor() {
			return new Color(this.color.getRed(), this.color.getGreen(), this.color.getBlue(), this.transparency);
		}

	}

	private class GitHubSynchrone {
		private UserName userName;

		public GitHubSynchrone(UserName userName) {
			this.userName = userName;
			OkHttpClient client = new OkHttpClient();
			String apiURL = "https://api.github.com/users/" + userName;// .getUserName();
			Request request = new Request.Builder().url(apiURL).build();
			try (Response response = client.newCall(request).execute();) {
				if (response.isSuccessful()) {
					System.out.println(response.body().string());
				}
			} catch (IOException e) {
				System.err.println(e);
			}
		}
	}

	private class GitHubWorker extends SwingWorker<String, Void> {
		private UserName userName;

		public GitHubWorker(UserName userName) {
			this.userName = userName;
		}

		@Override
		protected String doInBackground() throws Exception {
			OkHttpClient client = new OkHttpClient();
			String apiURL = "https://api.github.com/users/" + userName.getUserName();
			Request request = new Request.Builder().url(apiURL).build();
			try (Response response = client.newCall(request).execute();) {
				if (response.isSuccessful()) {
					return response.body().string();
				}
			} catch (IOException e) {
				System.err.println(e);
			}
			return null;

		}

		@Override
		protected void done() {
			try {
				System.out.println(get());
				String forecast = get();
				JSONObject jsonData = (JSONObject) JSONValue.parse(forecast);
				System.out.println("/n" + jsonData.get("name"));
			} catch (InterruptedException | ExecutionException e) {
				System.out.println(e);
			}
		}
	}

	private class GitHubEnQueue {
		private UserName userName;
		private String jsonData;

		private GitHubEnQueue(UserName userName) {
			this.userName = userName;
		}

		private void run() {
			OkHttpClient client = new OkHttpClient();
			String apiURL = Api.getGitHubUserUrl(userName);
			Request request = new Request.Builder().url(apiURL).build();
			Call call = client.newCall(request);
			call.enqueue(new Callback() {

				@Override
				public void onResponse(Call call, Response response) {
					try (ResponseBody body = response.body()) {
						if (response.isSuccessful()) {
							jsonData = response.body().string();
							getGithubUserDetails(jsonData);
							start();
						} else {
							Alert.errorMessage(contentPanel, Alert.GENERIC_ERROR_MESSAGE);
						}
					} catch (ParseException | IOException e) {
						Alert.errorMessage(contentPanel, Alert.GENERIC_ERROR_MESSAGE);
					}
				}

				@Override
				public void onFailure(Call call, IOException e) {
					Alert.errorMessage(contentPanel, Alert.GENERIC_CONNEXION_ERROR_MESSAGE);
				}
			});
		}

	}
	
	private void getGithubUserDetails(String jsonData) throws ParseException {
		JSONObject userData;
		userData = (JSONObject) JSONValue.parseWithException(jsonData);
		UserDataBuilder userDataBuilder = new UserDataBuilder();
		gitHubUser = userDataBuilder.setUserNameData((String) userData.get("name"))
											   .setUserBioData((String) userData.get("bio"))
											   .setUserDataAvatarURL((String) userData.get("avatar_url"))
											   .setUserDataFollowing((String) String.valueOf(userData.get("following")))
											   .setUserFollowersData((String) String.valueOf(userData.get("followers")))
											   .setUserLocationData((String) userData.get("location"))
											   .build();
		System.out.println(gitHubUser);
	}

}
